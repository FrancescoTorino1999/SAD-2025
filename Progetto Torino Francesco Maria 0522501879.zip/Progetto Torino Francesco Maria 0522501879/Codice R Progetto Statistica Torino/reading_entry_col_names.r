Comandi Progetto Torino Francesco Maria (Id Progetto: 34)


# Count delle entry

numero_entry <- nrow(dataset)
print(numero_entry)



# Controllo dei nomi delle colonne e tipo di dato per ogni feature

head(dataset)