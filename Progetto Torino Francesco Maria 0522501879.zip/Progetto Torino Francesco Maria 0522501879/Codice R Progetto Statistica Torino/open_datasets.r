Comandi Progetto Torino Francesco Maria (Id Progetto: 34)

setwd('/Users/francescomariatorino/Desktop/Università - 0522501879/Corsi/Statistica/Progetto')
#Dataset reale
dataset <- read.csv("Customer Churn.csv")
#Dataset con aggiunta la feature Second of use intervals
dataset <- read.csv("Customer Churn with Intervals.csv")
#Dataset Sintetico
dataset <- read.csv("synthetic_iranian_churn_dataset_with_outliers.csv")